GSAfisher.numeric <-
function(x,...){
  if (!inherits(x, "numeric")){ 
    stop("Input must be an object of class numeric")}
  if(any(!(x>0 & x<1))){
    stop("input data must be numeric vector of positive p-values < 1")}
  p<-pchisq(-2 * sum(log(x)),df=2*length(x),lower.tail=FALSE)
  return(p)
}
