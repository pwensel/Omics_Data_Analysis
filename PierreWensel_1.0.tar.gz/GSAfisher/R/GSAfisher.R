GSAfisher <-
function(x,...){
    UseMethod("GSAfisher")
}
