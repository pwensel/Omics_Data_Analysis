plotGSAfisher <-
function(x,...){
  if (!inherits(x, "GSAmultiple")){
    stop("Input must be an object of class GSAmultiple")
  }
  frame <- data.frame(index = numeric(), FSAFisher_statistic = numeric(), k = numeric(), Degrees_Of_Freedom= numeric(), p_value= numeric())
  count=0
  for (i in x){
    count=+1
    S<-(-2*sum(log(i)))
    k<-length(i)
    df<-2*k
    pvalue<- pchisq(S, df=df, lower.tail=FALSE)
    frame[count,]<-c(count,S, k, df, pvalue)
  }
  options(warn = -1)
  qqplot(-log(frame$p_value),rchisq(nrow(frame),df=frame$Degrees_Of_Freedom[1]),xlab="-log(p_value)",ylab="-log(distribution)",main="GSAfisher Test QQ-plot")
  #qqline(-log(frame$p_value),rchisq(nrow(frame),df=frame$Degrees_Of_Freedom[1]),col=2,distribution = function(p) qchisq(p, df = frame$Degrees_Of_Freedom[1]))
}
