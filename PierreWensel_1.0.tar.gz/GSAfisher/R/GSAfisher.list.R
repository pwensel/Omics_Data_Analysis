GSAfisher.list <-
function(x,...){
    if (!inherits(x, "list")){ 
    stop("Input must be an object of class list")}
    vector_list<-x
    p_vector=c()
    for(i in vector_list){
      p_vector <- append(p_vector, pchisq(-2 * sum(log(i)),df=2*length(i),lower.tail=FALSE))
    }
    return(p_vector)
  }
