printGSAfisher <-
function(obj,...){
  #if(class(obj)is("numeric")){
    cat("For the input numeric vector of ", length(obj), "p-values,\n")
    cat("The combined Fisher method p-value is: ", GSAfisher(obj), "\n")
    if(GSAfisher(obj)<=0.05){print("There is a global effect and the global null hypothesis H0 can be rejected")}
    else{print("There is no global effect and the global null hypothesis H0 cannot be rejected")}
  #}
  
  # #if(class(obj)is("list")){
  #   cat("For a list of ", length(obj), "vector elements:\n")
  #   count=0
  #   for(i in obj ){
  #     count<-count+1
  #     cat("The ", count, "th combined p-value is ", GSAfisher(i),"\n")
  #     if(GSAfisher(i)<=0.05){print("There is a global effect and the global null hypothesis H0 can be rejected")}
  #     else{print("There is no global effect and the global null hypothesis H0 cannot be rejected")}
  #   }
  # }
  # else {
  #   if(class(obj)is("GSAmultiple")){
  #     cat("For a GSAmultiple matrix-like object of ", ncol(obj), "columns:\n")
  #     p_vector<-apply(cbind(obj), 2, function (obj) pchisq(-2 * sum(log(obj)),df=2*length(obj),lower.tail=FALSE)) 
  #     cat("The combined", ncol(obj)," p-values are", p_vector,"\n")
  #   }
  # }
}
