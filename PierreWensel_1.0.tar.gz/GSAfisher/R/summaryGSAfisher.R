summaryGSAfisher <-
function(x,...){
  print("For the GSAFisher Combined Approach:\n")  
  print("Null Hypothesis: There is no global GSA effect\n")
  print("Alternative Hypothesis: There is a global GSA effect\n")
  print("The summary statistics (e.g. quartiles, mean, etc.) for the input numeric vector of p-values are as follows:\n")
  print(summary(x))
  print("\nThe summary statistics for the GSAfisher-processed input numeric vector of p-values are as follows:\n")
  S<-(-2*sum(log(x)))
  cat("Fisher_Combined_Statistic:", S, "\n")
  k<-length(x)
  cat("Number_Of_Tests", k, "\n")
  df<-(2*k)
  cat("Degrees_Of_Freedom", df, "\n")
  GSAfisher_pvalue<-GSAfisher(x)
  cat("GSAfisher pvalue: ", GSAfisher_pvalue, "\n")
  if(GSAfisher_pvalue<=0.05){
    print("There is a global GSA effect\n")
  }
  else{
    print("There is no global GSA effect\n")
  }
}
