GSAfisher.GSAmultiple <-
function(x,...){
    if (!inherits(x, "GSAmultiple")){
    stop("Input must be an object of class GSAmultiple")
    }
    p_vector<-apply(cbind(x,...), 2, function (x) pchisq(-2 * sum(log(x)),df=2*length(x),lower.tail=FALSE)) 
    return(p_vector)
}
